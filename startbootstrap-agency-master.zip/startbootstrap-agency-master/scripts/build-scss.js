'use strict';

const renderSCSS = require('./render-scss');

renderSCSS();
